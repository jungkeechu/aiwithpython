from perceptron_multiclass import PerceptronMultiClass
from training_data_processing import start_training_data_reading, \
                                    training_data_reading, \
                                    end_training_data_reading

import numpy as np
"""
input_datas = np.array(
                [
                    [0, 0, 1],
                    [0, 1, 1],
                    [1, 0, 1],
                    [1, 1, 1]
                ] 
                )

targets = np.array(
                [
                    [0, 0, 0, 1], 
                    [0, 0, 1, 0], 
                    [0, 1, 0, 0], 
                    [1, 0, 0, 0]
                ])
"""


def ttt_nn_training_with_data():
    f = start_training_data_reading()
    data_x, target_x, data_o, target_o = training_data_reading(f)
    #print("data_x:\n", data_x, target_x)
    #print("data_o:\n", data_o, target_o)
    end_training_data_reading(f)

    nn_for_x = PerceptronMultiClass(9, 9)
    nn_for_x.read_weights("weight_x.txt")
    nn_for_x.train(np.array(data_x), np.array(target_x), 30000)
    nn_for_x.test(np.array(data_x), np.array(target_x))
    nn_for_x.write_weights("weight_x.txt")

    nn_for_o = PerceptronMultiClass(9, 9)
    nn_for_o.read_weights("weight_o.txt")
    nn_for_o.train(np.array(data_o), np.array(target_o), 30000)
    nn_for_o.test(np.array(data_o), np.array(target_o))
    nn_for_o.write_weights("weight_o.txt")


if __name__ == '__main__':
    ttt_nn_training_with_data()
