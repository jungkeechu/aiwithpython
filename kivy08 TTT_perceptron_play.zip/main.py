from kivy.app import App
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from random import random
from nn import TicTacToe


from training_data_processing import start_training_data,\
                                    write_training_data,\
                                    end_training_data
SYMBOLS = ('X', 'O')

def symbol_generator():
    while True:
        for symbol in SYMBOLS:
            yield symbol


class Board(GridLayout):

    def __init__(self, game_ai, **kwargs):
        super(Board, self).__init__(**kwargs)

        self.game_ai = game_ai
        self.cols = 3
        self.rows = 3
        self.symbols = symbol_generator()
        self.grid = [None for _ in range(self.cols * self.rows)]
        self.draw_tiles()
        self.init_players()

    def init_players(self):
        """
        일단은 여기서 랜덤하게 AI의 순서를 정하자. AI가 먼저이면, 여기서 수를 하나두면 됨.
        """
        # trainging_data를 위한 파일 오픈
        self.training_file = start_training_data()


        # clear board
        for cell in self.grid:
            cell.text = ''

        # initialize symbol
        if next(self.symbols) == 'X':
            next(self.symbols)

        # who's first?
        if self.game_ai.nplayer == 2: # AI first
            # 게임 AI 내부적 업데이트
            index = self.game_ai.play_move()

            #########################################################################
            # training_data 쓰기
            data = []
            for cell in self.grid:
                data.append(cell.text)

            output = [+1 if x == index else 0 for x in range(self.cols * self.rows) ]
            write_training_data(self.training_file, data, output)
            #########################################################################

            # 화면 업데이트
            self.grid[index].text = next(self.symbols)

    def draw_tiles(self):
        """
            Adds all tiles to the GridLayout-Board
        """
        for index in range(self.rows * self.cols):
            tile = Button(font_size=100)
            tile.index = index ## 해당하는 버튼은 어디에 있는지 파악하기 위해서
            tile.bind(on_press=self.on_pressed)
            self.grid[index] = tile
            self.add_widget(tile)

    def on_pressed(self, instance):
        """
            Handles a click on a tile
            이 함수는 사람이 두는 부분이니까...
            사람이 두고 나면 --> 승패 판정하고 --> 끝나지 않았으면 --> AI가 둔다 --> 그리고 승패 판정
        """

        # if it is already taken
        if instance.text:
            return None

        # Human turn: 
        #########################################################################
        # training_data 쓰기
        data = []
        for cell in self.grid:
            data.append(cell.text)

        output = [+1 if x == instance.index else 0 for x in range(self.cols * self.rows) ]
        write_training_data(self.training_file, data, output)
        #########################################################################                   
        # 화면 업데이트
        instance.text = next(self.symbols)
        # 게임 AI 내부적 업데이트
        self.game_ai.make_move(instance.index, instance.text)

        # AI turn
        if not self.is_finished():
            # 게임 AI 내부적으로 업데이트
            index = self.game_ai.play_move()
            #########################################################################
            data = []
            for cell in self.grid:
                data.append(cell.text)

            output = [+1 if x == index else 0 for x in range(self.cols * self.rows) ]
            write_training_data(self.training_file, data, output)
            #########################################################################        
            # 화면에 업데이트
            self.grid[index].text = next(self.symbols)
            self.is_finished()

    def is_finished(self):
        """ check winner and draw popup window showing the final result.
        """

        #winner = self.game_ai.get_winner() ########
        if self.game_ai.is_lose(self.game_ai.AI):
            winner = self.game_ai.AI
        elif self.game_ai.is_lose(self.game_ai.HUMAN):
            winner = self.game_ai.HUMAN
        elif self.game_ai.is_over():
            winner = 'D'
        else:
            winner = None

        if winner:
            content = BoxLayout(orientation='vertical')
            if winner == 'D':
                content.add_widget(Label(text='Draw'))
            else:
                content.add_widget(Label(text='%s won the game!' % winner))

            close_button = Button(text='Close')
            content.add_widget(close_button)
            popup = Popup(title='Game Ends', content=content, auto_dismiss=False, size_hint=(.5, .5))
            popup.open()
            close_button.bind(on_press=lambda *args: self.restart_board(popup, *args))
            # training_data
            end_training_data(self.training_file, winner)

            return True
        else:
            return False
    
    def restart_board(self, *args):
        args[0].dismiss() # cloose popup window
        self.game_ai = TicTacToe(2 if random() > 0.4 else 1)
        self.init_players()


class TicTacToeApp(App):

    def build(self):
        # who's first?
        game_ai = TicTacToe(2 if random() > 0.5 else 1) # 디버깅을 위해서 AI가 먼저 두는 횟수를 많이 하려고 0.4와 비교
        return Board(game_ai)


if __name__ == '__main__':
    app = TicTacToeApp()
    app.run()