# -*- coding: utf-8 -*-

"""
수정 사항
- 2020년 6월 2일: numpy를 사용한다, 1차원으로 보드를 표현한다.
"""
import numpy as np
from perceptron_multiclass import PerceptronMultiClass

class TicTacToe():

    def __init__(self, nplayer): # if nplayer==2: AI first
        self.nplayer = nplayer
        self.cols = 3
        self.rows = 3
        self.AI ='X' if nplayer == 2 else 'O'
        self.HUMAN ='O' if nplayer == 2 else 'X'
        #self.board = [['' for col in range(self.cols)] for row in range(self.rows)]
        self.board = ['' for cell in range(self.cols * self.rows)]

        self.nn_ai = PerceptronMultiClass(9, 9)

        if self.AI == 'X':
            self.nn_ai.read_weights("weight_x.txt")
        else:
            self.nn_ai.read_weights("weight_o.txt")

       
    def possible_moves(self):
        #return [(r,c) for r in range(self.rows) for c in range(self.cols) if self.board[r][c] == '']
        #return [index for index in range(self.rows * self.cols) if self.board[index] == '']
        return [i for i,e in enumerate(self.board) if e=='']

    def make_move(self, index, symbol):
        self.board[index] = symbol

    def unmake_move(self, index):
        self.board[index] = ''
    
    def is_over(self):
        return (self.possible_moves() == [])

    def is_lose(self, symbol):
        """ Checks winning status.(심볼이 진 상태인지를 검사)
            
        Returns:
        """
        # winning checking
        # win/ lost가 뒤집힌듯 하다...
        return any( [all([(self.board[c] == symbol)
                for c in line])
                    for line in [[0,1,2],[3,4,5],[6,7,8], # horiz.
                                 [0,3,6],[1,4,7],[2,5,8], # vertical
                                 [0,4,8],[2,4,6]]]) # diagonal

    def play_move(self):
        board = self.board
        board = list(map(lambda x: 1 if x == 'X' else -1 if x == 'O' else 0, board))
        board.append(1)
        predict, net = self.nn_ai.predict(board)
    
        for i in range(len(net)):
            move = np.argmax(net)
            if move in self.possible_moves():
                self.make_move(move, self.AI)
                return move
            else:
                net[move] = -1

        return predict