# 파일 작업할 때 폴더의 위치를 주의해야함.
""" print(__file__)

import os
print(os.getcwd()) # cwd: current working directory """

# 파일의 종류에 따라,
# txt 파일, bin 파일, 엑셀 파일, JSON 파일 등 다양한 종류가 있다.


""" # 새로운 파일을 만들 때
#f = open("traing_data.txt", 'w')
# f = open(".\\my\\kivy08 TTT_perceptron\\fileio.txt", 'w')
f = open("fileio.txt", 'w')
f.write("first data\n")
f.write("second data\n")
f.close() """


input_file = "fileio.txt"

"""
# 기존의 파일에 끝에 추가할 때.
f =  open(input_file, 'a')
data = "added data\n"
f.write(data)
f.close() """


""" # readline() 함수로 한 줄 읽기
print("#### readline() ####")
f = open(input_file, 'r') # 파일을 읽기 전용으로 오픈
data = f.readline() # data변수에 파일에 있는 한 줄 대입
print(data)
f.close() """



""" # 파일 내부의 모든 줄을 읽으려면...
print("#### 반복문 + readline() ####")
f = open(input_file, 'r')

while True: # 무한 반복하면서
    data = f.readline() # 한 줄을 읽고
    if not data: #더 이상 읽어올 데이터가 없으면 반복 종료
        break
    print(data, end='')

f.close() """




""" # readlines() 함수는 모든 줄을 읽어온다.
print("#### readlines() ####")
f =  open(input_file, 'r')
lines = f.readlines()
print(lines)
for line in lines:
    print(line, end='')
f.close() """



# read() 함수는 파일의 모든 데이터를 하나의 문자열로 받아온다.
print("#### read() ####")
f =  open(input_file, 'r')
data = f.read()
print(data)

# 아래와같이 한 문자씩 출력할 수도 있다.
for ch in data:
    print(ch, end='')

f.close()



"""
# with 키워드 사용이 편하다.
with open(input_file, 'r') as f:
    data = f.read()
    print(data)
 """