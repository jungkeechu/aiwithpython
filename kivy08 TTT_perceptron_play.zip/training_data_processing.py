# Training data writing
buff = []

def start_training_data():
    global buff
    buff = []
    return open('training_data.txt', 'a')


def write_training_data(f, data, out):
    global buff

    for i, v in enumerate(data):
        if v == 'X':
            data[i] = +1
        elif v == 'O':
            data[i] = -1
        else:
            data[i] = 0
    
    # bias
    data.append(+1)
    buff.append((data, out))
  

def end_training_data(f, winner):
    global buff

    f.write(winner+"#"+str(len(buff))+"#"+str(buff)+"\n")
    buff = []
    
    f.close()

# D#9#[ ([0, 0, 0, 0, 0, 0, 0, 0, 0, 1], [1, -1, -1, -1, -1, -1, -1, -1, -1]), 
#       ([1, 0, 0, 0, 0, 0, 0, 0, 0, 1], [-1, -1, -1, -1, 1, -1, -1, -1, -1]), 
#       ([1, 0, 0, 0, -1, 0, 0, 0, 0, 1], [-1, 1, -1, -1, -1, -1, -1, -1, -1]), 
#       ([1, 1, 0, 0, -1, 0, 0, 0, 0, 1], [-1, -1, 1, -1, -1, -1, -1, -1, -1]), 
#       ([1, 1, -1, 0, -1, 0, 0, 0, 0, 1], [-1, -1, -1, -1, -1, -1, 1, -1, -1]), 
#       ([1, 1, -1, 0, -1, 0, 1, 0, 0, 1], [-1, -1, -1, 1, -1, -1, -1, -1, -1]), 
#       ([1, 1, -1, -1, -1, 0, 1, 0, 0, 1], [-1, -1, -1, -1, -1, 1, -1, -1, -1]), 
#       ([1, 1, -1, -1, -1, 1, 1, 0, 0, 1], [-1, -1, -1, -1, -1, -1, -1, 1, -1]), 
#       ([1, 1, -1, -1, -1, 1, 1, -1, 0, 1], [-1, -1, -1, -1, -1, -1, -1, -1, 1])]


# Training data reading 
def start_training_data_reading():
    return open('training_data.txt', 'r')

# 
def training_data_reading(f):
    data_x = []
    data_o = []
    target_x = []
    target_o = []

    lines = f.readlines()

    for line in lines:
        line_list = line.split("#")

        if line_list[0] == 'D':
            candidates = eval(line_list[2])
            for no in range(int(line_list[1])):
                if no % 2 == 0:
                    data_x.append(candidates[no][0])
                    target_x.append(candidates[no][1])
                else:
                    data_o.append(candidates[no][0])
                    target_o.append(candidates[no][1])

        elif line_list[0] == 'X':
            candidates = eval(line_list[2])
            for no in range(int(line_list[1])):
                if no % 2 == 1:
                    continue
                data_x.append(candidates[no][0])
                target_x.append(candidates[no][1])

        elif line_list[0] == 'O':
            candidates = eval(line_list[2])
            for no in range(int(line_list[1])):
                if no % 2 == 0:
                    continue
                data_o.append(candidates[no][0])
                target_o.append(candidates[no][1])

    print("#"*50)
    print("# of X: ", len(data_x), "\n", "# of O: ", len(data_o))

    return (data_x, target_x, data_o, target_o)


def end_training_data_reading(f):
    f.close()